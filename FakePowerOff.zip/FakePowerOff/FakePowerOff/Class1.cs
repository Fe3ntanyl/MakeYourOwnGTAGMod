﻿using GorillaLocomotion;
using GorillaNetworking;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace RandomAhhSkibidi
{
    public class Random
    {
        public static void ModNameHere()
        {
            // put code here. example: "GTPlayer.instance.maxJumpSpeed = 1.2f;"
            // and make sure to add all the required reference and usings.
        }
    }
}
